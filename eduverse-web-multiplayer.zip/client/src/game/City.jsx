import * as THREE from 'three';
import { useEffect, useRef } from 'react';

export default function City({ players, session, onMove }) {
  const mount = useRef(null);
  const keys = useRef({});
  const playerMeshes = useRef(new Map());
  const local = useRef({x:0,y:0,z:5});
  const onMoveRef = useRef(onMove);
  const playersRef = useRef(players);
  const sessionRef = useRef(session);
  onMoveRef.current = onMove;
  playersRef.current = players;
  sessionRef.current = session;

  useEffect(() => {
    const host = mount.current;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#83c9ff');
    scene.fog = new THREE.Fog('#83c9ff', 35, 115);
    const camera = new THREE.PerspectiveCamera(65, host.clientWidth/host.clientHeight, .1, 250);
    camera.position.set(0, 7, 13);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
    renderer.setSize(host.clientWidth, host.clientHeight);
    renderer.shadowMap.enabled = true;
    host.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0xffffff, 0x52709a, 2));
    const sun = new THREE.DirectionalLight(0xffffff, 2.2);
    sun.position.set(-15,25,12); sun.castShadow=true; scene.add(sun);

    const mat = (color, roughness=.85) => new THREE.MeshStandardMaterial({color,roughness});
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(180,180), mat('#5bbf78'));
    ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);
    const road = new THREE.Mesh(new THREE.PlaneGeometry(13,130), mat('#394b67'));
    road.rotation.x=-Math.PI/2; road.position.y=.02; road.receiveShadow=true; scene.add(road);
    for(let z=-55;z<65;z+=9){
      const stripe=new THREE.Mesh(new THREE.PlaneGeometry(.25,4),mat('#ffe58a'));
      stripe.rotation.x=-Math.PI/2; stripe.position.set(0,.04,z); scene.add(stripe);
    }
    const buildings = [
      [-13,-15,8,13,9,'#2789d8','SCIENCE'],[14,-18,9,17,12,'#8d65db','HISTORY'],
      [-14,12,8,16,11,'#ed9d35','MATH'],[14,14,10,12,10,'#1caeaa','LANGUAGE'],
      [-27,0,7,9,8,'#4777b9','DISCOVERY'],[28,-3,8,14,13,'#e16c8a','CAMPUS']
    ];
    buildings.forEach(([x,z,w,h,d,c,label])=>{
      const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(c));
      b.position.set(x,h/2,z); b.castShadow=true; b.receiveShadow=true; scene.add(b);
      const roof=new THREE.Mesh(new THREE.BoxGeometry(w+.7,.5,d+.7),mat('#e9f4ff'));
      roof.position.set(x,h+.25,z); scene.add(roof);
      for(let yy=2;yy<h-1;yy+=2.4) for(let xx=-w/2+1;xx<w/2;xx+=2.2){
        const win=new THREE.Mesh(new THREE.BoxGeometry(.9,1.1,.12),mat('#a9e9ff',.25));
        win.position.set(x+xx,yy,z+d/2+.08); scene.add(win);
      }
      const sign=new THREE.Mesh(new THREE.BoxGeometry(w*.9,1.15,.25),mat('#082b65'));
      sign.position.set(x,h*.68,z+d/2+.3); scene.add(sign);
      const canvas=document.createElement('canvas'); canvas.width=512;canvas.height=128;
      const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.font='bold 54px Arial';ctx.textAlign='center';ctx.fillText(label,256,82);
      const texture=new THREE.CanvasTexture(canvas);
      const text=new THREE.Mesh(new THREE.PlaneGeometry(w*.85,.85),new THREE.MeshBasicMaterial({map:texture,transparent:true}));
      text.position.set(x,h*.68,z+d/2+.45);scene.add(text);
    });
    for(let i=0;i<24;i++){
      const x=(i%2?1:-1)*(18+Math.random()*18), z=-55+i*5;
      const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.25,.4,2,6),mat('#80512f'));
      trunk.position.set(x,1,z);scene.add(trunk);
      const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.7,1),mat('#159b68'));
      crown.position.set(x,3,z);crown.castShadow=true;scene.add(crown);
    }
    const makeAvatar=(color='#ffcb65')=>{
      const group=new THREE.Group();
      const body=new THREE.Mesh(new THREE.BoxGeometry(.9,1.15,.48),mat(color));
      body.position.y=1.25;body.castShadow=true;group.add(body);
      const head=new THREE.Mesh(new THREE.BoxGeometry(.72,.72,.68),mat('#f2bd91'));
      head.position.y=2.2;head.castShadow=true;group.add(head);
      const hair=new THREE.Mesh(new THREE.BoxGeometry(.76,.22,.72),mat('#38251d'));
      hair.position.set(0,2.58,0);group.add(hair);
      const legs=new THREE.Mesh(new THREE.BoxGeometry(.72,.75,.42),mat('#183b75'));
      legs.position.y=.38;group.add(legs);
      return group;
    };
    const me=makeAvatar('#e94d50');scene.add(me);
    const resize=()=>{camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight);};
    window.addEventListener('resize',resize);
    const down=e=>{keys.current[e.key.toLowerCase()]=true;};
    const up=e=>{keys.current[e.key.toLowerCase()]=false;};
    window.addEventListener('keydown',down);window.addEventListener('keyup',up);
    let frame, lastNetworkSend=0;
    const animate=(now=0)=>{
      frame=requestAnimationFrame(animate);
      const k=keys.current, speed=.17;
      if(k.w||k.arrowup)local.current.z-=speed;
      if(k.s||k.arrowdown)local.current.z+=speed;
      if(k.a||k.arrowleft)local.current.x-=speed;
      if(k.d||k.arrowright)local.current.x+=speed;
      local.current.x=THREE.MathUtils.clamp(local.current.x,-7,7);
      local.current.z=THREE.MathUtils.clamp(local.current.z,-58,58);
      me.position.set(local.current.x,0,local.current.z);
      camera.position.lerp(new THREE.Vector3(me.position.x,7,me.position.z+12),.09);
      camera.lookAt(me.position.x,1.1,me.position.z-2);
      if(now-lastNetworkSend>80){onMoveRef.current?.({...local.current});lastNetworkSend=now;}
      const seen=new Set();
      playersRef.current?.forEach?.((p)=>{
        if(p.id===sessionRef.current?.sessionId)return;
        seen.add(id);
        let mesh=playerMeshes.current.get(id);
        if(!mesh){mesh=makeAvatar('#4e9cff');scene.add(mesh);playerMeshes.current.set(id,mesh);}
        mesh.position.set(p.x||0,0,p.z||0);
      });
      for(const [id,mesh] of playerMeshes.current){if(!seen.has(id)){scene.remove(mesh);playerMeshes.current.delete(id);}}
      renderer.render(scene,camera);
    };
    animate();
    return ()=>{cancelAnimationFrame(frame);window.removeEventListener('resize',resize);window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);renderer.dispose();host.removeChild(renderer.domElement);};
  },[]);
  return <div className="city" ref={mount}><div className="sceneHint">WASD / tombol panah untuk bergerak</div></div>;
}
