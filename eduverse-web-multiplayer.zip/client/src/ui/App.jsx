import React,{useEffect,useRef,useState} from 'react';
import {Client} from '@colyseus/sdk';
import City from '../game/City.jsx';

const SERVER=import.meta.env.VITE_GAME_SERVER_URL || 'ws://localhost:2567';
export default function App(){
 const [mode,setMode]=useState('home'),[name,setName]=useState(''),[code,setCode]=useState(''),[room,setRoom]=useState(null),[state,setState]=useState(null),[players,setPlayers]=useState([]),[error,setError]=useState('');
 const [question,setQuestion]=useState(null),[notice,setNotice]=useState(''),[answer,setAnswer]=useState('');
 const [subject,setSubject]=useState('IPAS'),[topic,setTopic]=useState('Sistem Pencernaan Manusia'),[duration,setDuration]=useState(600),[qtext,setQtext]=useState('Organ yang menyerap sebagian besar zat gizi adalah ...?');
 const client=useRef(null);
 const connect=async(role)=>{
  try{
   setError(''); client.current=new Client(SERVER);
   let r;
   if(role==='teacher') r=await client.current.create('eduverse',{name:name||'Guru',role,subject,topic,duration,questions:[{text:qtext,options:['Lambung','Usus halus','Kerongkongan','Mulut'],correct:1,points:100}]});
   else r=await client.current.join('eduverse',{name:name||'Pemain',role,code:code.toUpperCase()});
   setRoom(r);setMode('game');
   r.onStateChange(s=>{setState({...s,players:Array.from(s.players.entries()).map(([id,p])=>({id,...p}))});setPlayers(Array.from(s.players.entries()).map(([id,p])=>({id,...p})));});
   r.onMessage('question',q=>{setQuestion(q);setAnswer('');});
   r.onMessage('notice',m=>setNotice(m.text));
   r.onMessage('roomCode',m=>setCode(m.code));
   r.onMessage('result',m=>{setNotice(m.correct?'CORRECT! +'+m.points+' poin':'TRY AGAIN!');if(m.correct)setQuestion(null);});
   r.onLeave(()=>{setNotice('Koneksi ke room terputus. Muat ulang untuk bergabung kembali.');});
  }catch(e){setError(e.message||'Tidak dapat terhubung ke server. Pastikan server berjalan.');}
 };
 const sendMove=p=>room?.send('move',p);
 const start=()=>room?.send('startLearning');
 const submit=()=>room?.send('answer',{answer:Number(answer)});
 useEffect(()=>()=>{room?.leave();},[room]);
 if(mode==='home')return <main className="landing"><div className="hero"><div className="brand">★ EDUVERSE</div><div className="subtitle">THE LEARNING CITY</div><h1>Explore, Learn, Race, and Win!</h1><p>Jelajahi kota, pelajari materi, lalu tantang temanmu.</p><button className="primary" onClick={()=>setMode('role')}>▶ PLAY</button><div className="featureRow"><span>🏙️ Open City</span><span>👥 Multiplayer</span><span>🧠 Quiz Race</span></div></div></main>;
 if(mode==='role')return <main className="center"><section className="panel"><div className="brand small">EDUVERSE</div><h2>Masuk ke Learning City</h2><label>Nama pemain</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Nama kamu"/><div className="roleGrid"><button onClick={()=>setMode('teacher')}>👩‍🏫 Mode Guru</button><button onClick={()=>setMode('student')}>🎮 Mode Siswa</button></div><button className="ghost" onClick={()=>setMode('home')}>Kembali</button></section></main>;
 if(mode==='teacher')return <main className="center"><section className="panel"><h2>Teacher Setup</h2><label>Nama guru</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Nama guru"/><label>Mata pelajaran</label><input value={subject} onChange={e=>setSubject(e.target.value)}/><label>Topik</label><input value={topic} onChange={e=>setTopic(e.target.value)}/><label>Durasi belajar (detik)</label><input type="number" value={duration} onChange={e=>setDuration(+e.target.value)}/><label>Contoh soal checkpoint</label><textarea value={qtext} onChange={e=>setQtext(e.target.value)}/><button className="primary" onClick={()=>connect('teacher')}>BUAT ROOM</button><button className="ghost" onClick={()=>setMode('role')}>Kembali</button>{error&&<p className="error">{error}</p>}</section></main>;
 if(mode==='student')return <main className="center"><section className="panel"><h2>Join Adventure</h2><label>Nama pemain</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Nama kamu"/><label>Kode room</label><input value={code} onChange={e=>setCode(e.target.value.toUpperCase())} placeholder="Contoh: A7K2Q9"/><button className="primary" onClick={()=>connect('student')}>JOIN ROOM</button><button className="ghost" onClick={()=>setMode('role')}>Kembali</button>{error&&<p className="error">{error}</p>}</section></main>;
 return <main className="gameShell"><City players={players} session={room} onMove={sendMove}/><header className="hud"><b>EDUVERSE</b><span>{state?.subject||subject} · {state?.topic||topic}</span><span>⏱ {state?.remaining??'--'}s</span><span>👥 {players.length}</span></header><aside className="gamePanel"><b>{state?.phase||'LOBBY'}</b><p>{notice||'Jelajahi Learning City bersama temanmu.'}</p>{room?.sessionId===state?.teacherId&&state?.phase==='lobby'&&<button className="primary" onClick={start}>START LEARNING</button>}<div className="players">{players.map(p=><small key={p.id}>🧑 {p.name}</small>)}</div>{state?.roomCode&&<small>KODE ROOM: <strong>{state.roomCode}</strong></small>}</aside>{question&&<div className="modal"><section className="panel"><h2>Checkpoint Quiz</h2><p>{question.text}</p>{question.options.map((o,i)=><button className={answer===String(i)?'selected':'option'} key={i} onClick={()=>setAnswer(String(i))}>{String.fromCharCode(65+i)}. {o}</button>)}<button className="primary" disabled={answer==='' } onClick={submit}>KIRIM JAWABAN</button></section></div>}<div className="mobileControls"><div className="dpad"><button onTouchStart={()=>sendMove({x:-1,z:0})} onTouchEnd={()=>sendMove({x:0,z:0})}>◀</button><button onTouchStart={()=>sendMove({x:1,z:0})} onTouchEnd={()=>sendMove({x:0,z:0})}>▶</button><button onTouchStart={()=>sendMove({x:0,z:-1})} onTouchEnd={()=>sendMove({x:0,z:0})}>▲</button><button onTouchStart={()=>sendMove({x:0,z:1})} onTouchEnd={()=>sendMove({x:0,z:0})}>▼</button></div></div></main>;
}
