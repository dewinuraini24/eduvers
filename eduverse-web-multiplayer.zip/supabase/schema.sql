-- Starter schema. Enable RLS and add policies before production use.
create table if not exists public.teacher_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists public.subjects (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teacher_profiles(id) on delete cascade,
  name text not null,
  topic text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists public.learning_templates (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teacher_profiles(id) on delete cascade,
  title text not null,
  config jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.game_sessions (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teacher_profiles(id) on delete cascade,
  room_code text not null,
  subject text not null,
  topic text not null,
  phase text not null default 'lobby',
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.session_participants (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.game_sessions(id) on delete cascade,
  display_name text not null,
  score integer not null default 0,
  correct_answers integer not null default 0,
  completion_seconds integer,
  created_at timestamptz not null default now()
);
alter table public.teacher_profiles enable row level security;
alter table public.subjects enable row level security;
alter table public.learning_templates enable row level security;
alter table public.game_sessions enable row level security;
alter table public.session_participants enable row level security;
-- TODO: add owner-only policies for teacher tables and safe read policies for session participants.
