import { Room } from 'colyseus';
import { Schema, MapSchema, type } from '@colyseus/schema';
import { randomBytes } from 'node:crypto';

class Player extends Schema {
  constructor(name,role){super();this.name=name;this.role=role;this.x=0;this.z=5;this.score=0;this.correct=0;this.finished=false;}
}
type('string')(Player.prototype,'name');type('string')(Player.prototype,'role');
type('number')(Player.prototype,'x');type('number')(Player.prototype,'z');
type('number')(Player.prototype,'score');type('number')(Player.prototype,'correct');type('boolean')(Player.prototype,'finished');
class GameState extends Schema {
 constructor(){super();this.players=new MapSchema();this.phase='lobby';this.remaining=0;this.subject='';this.topic='';this.roomCode='';this.teacherId='';this.startedAt=0;}
}
type({map:Player})(GameState.prototype,'players');type('string')(GameState.prototype,'phase');
type('number')(GameState.prototype,'remaining');type('string')(GameState.prototype,'subject');
type('string')(GameState.prototype,'topic');type('string')(GameState.prototype,'roomCode');
type('string')(GameState.prototype,'teacherId');type('number')(GameState.prototype,'startedAt');

export class EduverseRoom extends Room {
 onCreate(options){
  this.setState(new GameState());
  this.state.subject=options.subject||'IPAS';this.state.topic=options.topic||'Pembelajaran';
  this.duration=Math.max(60,Math.min(3600,Number(options.duration)||600));
  this.questions=(options.questions||[]).slice(0,30);
  this.questionIndex=0;this.activeQuestion=null;this.answerDeadline=0;
  this.state.roomCode=randomBytes(4).toString('hex').slice(0,6).toUpperCase();
  this.maxClients=40;
  this.setMetadata({code:this.state.roomCode});
  this.onMessage('move',(client,data)=>this.move(client,data));
  this.onMessage('startLearning',client=>this.start(client));
  this.onMessage('answer',(client,data)=>this.answer(client,data));
  this.setSimulationInterval(()=>this.tick(),250);
 }
 onJoin(client,options){
  const role=options.role==='teacher'?'teacher':'student';
  if(role==='teacher'&&this.state.teacherId)throw new Error('Room sudah memiliki guru.');
  if(role==='student'&&options.code?.toUpperCase()!==this.state.roomCode)throw new Error('Kode room tidak sesuai.');
  if(role==='student'&&this.state.phase!=='lobby')throw new Error('Permainan sudah dimulai.');
  this.state.players.set(client.sessionId,new Player(String(options.name||'Pemain').slice(0,22),role));
  if(role==='teacher'){this.state.teacherId=client.sessionId;client.send('roomCode',{code:this.state.roomCode});}
  this.broadcast('notice',{text:`${options.name||'Pemain'} bergabung ke Learning City.`});
 }
 onLeave(client){this.state.players.delete(client.sessionId);if(client.sessionId===this.state.teacherId)this.broadcast('notice',{text:'Guru terputus dari room.'});}
 move(client,data){
  const p=this.state.players.get(client.sessionId);if(!p||this.state.phase!=='learning')return;
  const x=Math.max(-7,Math.min(7,Number(data.x)||0)),z=Math.max(-58,Math.min(58,Number(data.z)||0));
  p.x=x;p.z=z;
 }
 start(client){
  if(client.sessionId!==this.state.teacherId||this.state.phase!=='lobby')return;
  this.state.phase='learning';this.state.remaining=this.duration;this.state.startedAt=Date.now();
  this.broadcast('notice',{text:'LEARNING TIME STARTED! Jelajahi kota dan pelajari materi.'});
 }
 tick(){
  if(this.state.phase==='learning'){
   this.state.remaining=Math.max(0,Math.ceil((this.duration*1000-(Date.now()-this.state.startedAt))/1000));
   if(this.state.remaining===0){this.state.phase='quiz-race';this.broadcast('notice',{text:'LEARNING TIME IS OVER! Petualangan berikutnya dimulai.'});this.askQuestion();}
  }
  if(this.state.phase==='quiz-race'&&this.activeQuestion&&Date.now()>this.answerDeadline){
   this.broadcast('notice',{text:'Waktu menjawab habis.'});this.activeQuestion=null;
  }
 }
 askQuestion(){
  if(this.questionIndex>=this.questions.length){this.state.phase='results';this.broadcast('notice',{text:'Permainan selesai!'});return;}
  const q=this.questions[this.questionIndex++];
  this.activeQuestion=q;this.answerDeadline=Date.now()+30000;
  // Correct answer is deliberately omitted from the client message.
  this.broadcast('question',{text:q.text,options:q.options,deadline:this.answerDeadline});
 }
 answer(client,data){
  const p=this.state.players.get(client.sessionId);if(!p||!this.activeQuestion||Date.now()>this.answerDeadline)return;
  const correct=Number(data.answer)===Number(this.activeQuestion.correct);
  if(correct){p.score+=Number(this.activeQuestion.points)||100;p.correct+=1;client.send('result',{correct:true,points:Number(this.activeQuestion.points)||100});}
  else client.send('result',{correct:false,points:0});
  if(correct){this.activeQuestion=null;this.clock=setTimeout(()=>this.askQuestion(),900);}
 }
}
