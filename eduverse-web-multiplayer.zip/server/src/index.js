import { Server } from 'colyseus';
import { WebSocketTransport } from '@colyseus/ws-transport';
import { EduverseRoom } from './room.js';
const port=Number(process.env.PORT||2567);
const gameServer=new Server({transport:new WebSocketTransport({port})});
gameServer.define('eduverse',EduverseRoom).filterBy(['code']);
gameServer.listen(port).then(()=>console.log(`EDUVERSE server listening on ${port}`));
