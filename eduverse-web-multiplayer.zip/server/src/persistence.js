// Persistence adapter placeholder.
// Connect Supabase from the server only. Keep the service-role key out of the browser.
// Implement: saveTemplate, loadTemplate, saveSessionResult, listTeacherTemplates.
export const persistence = {
  async saveTemplate(_teacherId,_template) { throw new Error('Supabase persistence belum dikonfigurasi.'); },
  async loadTemplate(_teacherId,_templateId) { throw new Error('Supabase persistence belum dikonfigurasi.'); },
  async saveSessionResult(_session) { throw new Error('Supabase persistence belum dikonfigurasi.'); }
};
